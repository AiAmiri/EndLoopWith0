import java.util.*;
public class EndLoopWithSentinalValue_0 {
	public static void main(String[] args) {
	Scanner input = new Scanner (System.in);
	int i=0;
	System.out.println("enter a  value first" );
	do{
	int x=input.nextInt();
    if (x==0) break;
    else {
    i +=x;
    System.out.println("result is "+i);
    continue;
    }
	} while(2>1);
		
	}
}